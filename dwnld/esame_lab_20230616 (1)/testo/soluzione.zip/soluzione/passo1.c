// Test della funzione giocatore()
#include "giocatore.h"

// La funzione main si limita a invocare la funzione da testare
int main() {
    giocatore();
    // la funzione contiene un loop infinito, quindi non si arriverà mai a questo punto.
}
