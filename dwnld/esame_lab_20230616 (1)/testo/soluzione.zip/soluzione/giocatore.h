// Prototipo della funzione giocatore
void giocatore();
