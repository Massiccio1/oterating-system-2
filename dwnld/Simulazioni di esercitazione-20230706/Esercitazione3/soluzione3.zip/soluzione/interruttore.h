/*
interruttore.h
Prototipo della funzione che gestisce l'interruttore
*/

// Argomento: fd è il descrittore di scrittura della pipe anonima
// per la comunicazione con la centralina.
void interruttore(int fd);
